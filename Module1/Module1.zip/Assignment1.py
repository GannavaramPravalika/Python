>>> num1=int(input())
6
>>> num2=int(input())
4
>>> print(num1+num2)
10
>>> print(num1-num2)
2
>>> print(num1*num2)
24
>>>

