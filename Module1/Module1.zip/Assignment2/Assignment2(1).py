+num=21
+num2=int(input())
+print(num1-num2)
+num2=int(input())
+print(num1-num2)
+num2=int(input())
+print(num1-num2)